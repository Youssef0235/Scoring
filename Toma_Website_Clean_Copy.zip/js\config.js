/**
 * Toma el Rasol - Application Configuration
 * 
 * Replace SUPABASE_URL and SUPABASE_ANON_KEY with your live Supabase project details.
 * If left empty or invalid, the application automatically uses the local storage mock driver
 * so all features, workflows, and UI interactions work immediately offline or in demo mode!
 */
window.APP_CONFIG = {
  // Live Supabase Credentials (Optional: Leave empty for local storage offline mode, or enter your Supabase credentials)
  SUPABASE_URL: '',
  SUPABASE_ANON_KEY: '',

  // App Settings
  APP_NAME: 'Toma el Rasol',
  CHURCH_CLASS: 'St. Thomas Youth Class',
  DEFAULT_QR_BASE_URL: window.location.origin + window.location.pathname.replace(/Toma_elrasol\.html|admin\/index\.html|user\/index\.html/g, '') + 'user/index.html'
};
